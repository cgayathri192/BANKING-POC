import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BankingService {
  registerAPI = "http://localhost:3000/registerApi"
  loginAPI = "http://localhost:3000/login"
  depositAPI= "http://localhost:3000/deposit"
  withdrawAPI=' http://localhost:3000/withdraw'
  balanceAPI="http://localhost:3000/balance"
  pinGeneration='http://localhost:3000/pinGeneration'
  transferApi="http://localhost:3000/transferApi"
  constructor(private http: HttpClient) {

  }

  register(data: any) {
    return this.http.post(this.registerAPI, data)
  }
  login(data: any) {
    return this.http.post(this.loginAPI, data)
  }
  postDeposit(data:any){
    return this.http.post(this.depositAPI,data)
  }
  postWithdraw(data:any){
    return this.http.post(this.withdrawAPI,data)
  }
  postBalance(data:any){
    return this.http.post(this.balanceAPI,data)
  }
  postPinGeneration(data:any){
    return this.http.post(this.pinGeneration,data)
  }
  transferMoney(data:any){
    return this.http.post(this.transferApi,data)
  }
  updateDeposit(data:any,id:any){
    return this.http.put(`${this.depositAPI}/${id}`,data)
  }
}
