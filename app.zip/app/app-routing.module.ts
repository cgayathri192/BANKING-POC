import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { BankingGuard } from './banking.guard';
import { TermsComponent } from './terms/terms.component';
import { ScannerComponent } from './scanner/scanner.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { MainComponent } from './main/main.component';


const routes: Routes = [
  {
    path:"register",
    component:RegisterComponent
  },
  {
    path:"",
    component:LoginComponent
  },
  {
    path:"home",
    component:HomeComponent,
    canActivate: [BankingGuard],
  },
  {
    path:"terms",
    component:TermsComponent,
    canActivate: [BankingGuard]
  },
  {
    path:'scanner',
    component:ScannerComponent,
    canActivate: [BankingGuard],
  },
  {
    path:'details',
    component:UserdetailsComponent,
    canActivate: [BankingGuard],
  },
  {
    path:'main',
    component:MainComponent,
    canActivate: [BankingGuard],
    children:[
      {path:'',component:HomeComponent},
      {path:'terms',component:TermsComponent},
      {path:'scanner',component:ScannerComponent},
      {path:'home',component:HomeComponent},
      {path:'details',component:UserdetailsComponent}
    ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
