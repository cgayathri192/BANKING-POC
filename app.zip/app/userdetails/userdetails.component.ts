import { Component } from '@angular/core';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.scss'],
})
export class UserdetailsComponent {
  name = sessionStorage.getItem('name');
  accountNumber = sessionStorage.getItem('accountNumber');
  email = sessionStorage.getItem('email');
  bankName = sessionStorage.getItem('bankName');
  ifsc = sessionStorage.getItem('ifsc');
  branchName = sessionStorage.getItem('branchName');
  accountType = sessionStorage.getItem('type');
  mobile = sessionStorage.getItem('mobile');
}
