import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BankingService } from '../banking.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: any
  constructor(private service: BankingService, private router: Router) {

  }
  getControl(name: any): AbstractControl | null {
    return this.registerForm.get(name)

  }
  ngOnInit() {
    this.registerForm = new FormGroup({
      name: new FormControl("", [Validators.required, Validators.minLength(6)]),
      email: new FormControl("", [Validators.required]),
      password: new FormControl("", [Validators.required, Validators.minLength(8)]),
      retypepassword: new FormControl("", [Validators.required, Validators.minLength(8)]),
      bankName: new FormControl("", [Validators.required]),
      accountNumber: new FormControl("", [Validators.required, Validators.minLength(12)]),
      ifscCode: new FormControl("", [Validators.required]),
      branchName: new FormControl("", [Validators.required]),
      accountType: new FormControl("", [Validators.required]),
      mobile: new FormControl('', [Validators.required, Validators.minLength(10)]),
      checkbox: new FormControl("", [Validators.required,Validators.minLength(8)]),
    })
    
  }

  register() {
    const x = this.registerForm.value
    const accountData = {

      name: x.name,
      email: x.email,
      password: x.password,
      retypepassword: x.retypepassword,
      bankName: x.bankName,
      accountNumber: x.accountNumber,
      ifscCode: x.ifscCode,
      branchName: x.branchName,
      accountType: x.accountType,
      mobile: x.mobile,
      balance: 0

    }
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })

    Toast.fire({
      icon: 'success',
      title: 'Registered successfully!'
    })

    this.service.register(accountData).subscribe((x: any) => {
      sessionStorage.setItem('name', x.name)
      sessionStorage.setItem('accountNumber', x.accountNumber)
      sessionStorage.setItem('password', x.password)
      sessionStorage.setItem('email', x.email)
      sessionStorage.setItem('bankName', x.bankName)
      sessionStorage.setItem('ifsc', x.ifscCode)
      sessionStorage.setItem('branchName', x.branchName)
      sessionStorage.setItem('type', x.accountType)
      sessionStorage.setItem('mobile', x.mobile)

      if (x.password == x.retypepassword) {
        this.router.navigateByUrl('main')
      }
    })
  }
}
