import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  NgxQrcodeElementTypes,
  NgxQrcodeErrorCorrectionLevels,
} from '@techiediaries/ngx-qrcode';
import { BankingService } from '../banking.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  generate='Generate Pin'
  depositForm: any;
  rechargeForm: any;
  balanceForm: any;
  transferForm: any;
  generatePin: any;
  elementType = NgxQrcodeElementTypes.URL;
  correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
  value = 'https://www.axisbank.com/';
  value1 = 'https://www.whatsapp.com';
  username = sessionStorage.getItem('name');
  totalAmount: any;
  generatedPin = sessionStorage.getItem('generatedPin');
  depositMoney: any = sessionStorage.getItem('deposit');
  transferMoney: any = sessionStorage.getItem('transfer');
  rechargeMoney: any = sessionStorage.getItem('recharge');
  message = 'Entered pin is wrong';

  constructor(private service: BankingService, private route: Router) {}
  getControl(name: any): AbstractControl | null {
    return this.depositForm.get(name);
  }
  getControl1(name: any): AbstractControl | null {
    return this.rechargeForm.get(name);
  }
  getControl2(name: any): AbstractControl | null {
    return this.balanceForm.get(name);
  }
  getControl3(name: any): AbstractControl | null {
    return this.transferForm.get(name);
  }
  getControl4(name: any): AbstractControl | null {
    return this.generatePin.get(name);
  }
  ngOnInit(): void {
    this.depositForm = new FormGroup({
      accountNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(12),
      ]),
      amount: new FormControl('', [Validators.required]),
      pin: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
    this.rechargeForm = new FormGroup({
      mobileNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(12),
      ]),
      operator: new FormControl('', [Validators.required]),
      pack:new FormControl('',Validators.required),
      pin: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
    this.balanceForm = new FormGroup({
      pin: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
    this.transferForm = new FormGroup({
      name: new FormControl('', [Validators.required]),
      accountNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(12),
      ]),
      amount: new FormControl('', [Validators.required]),
      pin: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
    this.generatePin = new FormGroup({
      enterPin: new FormControl('', [
        Validators.required,
        Validators.minLength(6),
      ]),
      confirmPin: new FormControl('', [
        Validators.required,
        Validators.minLength(6),
      ]),
    });
  }
  changeText(){
    this.generate="Change Pin"

  }
  deposit() {
    this.service.postDeposit(this.depositForm.value).subscribe((x: any) => {
      console.log(x);
      const depositAccountNumber = sessionStorage.getItem('accountNumber');
      sessionStorage.setItem('deposit', x.amount);
      if (depositAccountNumber === x.accountNumber) {
        console.log('depositaccountnumber', depositAccountNumber);
      }
    });
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Money deposited  successfully!',
    });
  }

  recharge() {
    this.service.postWithdraw(this.rechargeForm.value).subscribe((x: any) => {
      sessionStorage.setItem('recharge', x.pack);
      console.log(x);
    });
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Money Withdrawn  successfully!',
    });
  }

  checkBalance() {
    this.service.postBalance(this.balanceForm.value).subscribe((x: any) => {
      console.log('balancePin', x.pin);
      if (x.pin == this.generatedPin) {
        this.totalAmount =
          (this.depositMoney - this.rechargeMoney - this.transferMoney)
        console.log("balance",this.totalAmount);
        console.log('abcd', this.generatedPin);
      } else {
        this.message;
        console.log('message');
      }
    });
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Balance fetched  successfully!',
    });
  }

  pinGeneration() {
    this.service
      .postPinGeneration(this.generatePin.value)
      .subscribe((x: any) => {
        if (x.enterPin === x.confirmPin) {
          sessionStorage.setItem('generatedPin', x.enterPin);
          console.log('pin generated succesfully');
          console.log(x.enterPin);
          // console.log("generatedpin",x.generatedPin)
        } else {
          console.log('entered pin is wrong');
        }
      });
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Pin generated  successfully!',
    });
  }
  upi() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'UPI Scanner',
    });
  }
  whatsapp() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Whatsapp Banking',
    });
  }
  transfer() {
    this.service.transferMoney(this.transferForm.value).subscribe((x: any) => {
      sessionStorage.setItem('transfer', x.amount);
      console.log(x);
    });
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Money Transfered Succufully !',
    });
  }
  logout() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Logout Succufully !',
    });
  }
  terms() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Terms & Conditions!',
    });
  }
}
