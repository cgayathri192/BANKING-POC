import { Component, OnInit } from '@angular/core';
import { AbstractControl,FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BankingService } from '../banking.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: any
  loginUser = ''
  regex = /^[0-9]*$/;
  constructor(private service: BankingService, private router: Router) {

  }
  ngOnInit() {
    this.loginForm = new FormGroup({
      accountNumber: new FormControl("", [Validators.required,Validators.minLength(12)]),
      password: new FormControl("", [Validators.required,Validators.minLength(8)]),
      
    })

  }
  getControl(name: any): AbstractControl | null {
    return this.loginForm.get(name)

  }
  login() {
    this.loginForm
    this.service.login(this.loginForm.value).subscribe((x: any) => {
      // console.log(x)

      const loginAccountNumber = sessionStorage.getItem('accountNumber')
      const loginPassword = sessionStorage.getItem('password')
      // const loginID=sessionStorage.getItem('id')
      // console.log('loginID',loginID)
      sessionStorage.setItem('loggedIn', 'true')
      this.router.navigateByUrl('main')
      if (loginAccountNumber == x.accountNumber && loginPassword == x.password) {
        this.router.navigateByUrl('main')
      } else {
        this.router.navigateByUrl('login')
      }

    })
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast:any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    
    Toast.fire({
      icon: 'success',
      title: 'Login successfull!'
    })
  }
}
