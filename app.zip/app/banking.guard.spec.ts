import { TestBed } from '@angular/core/testing';

import { BankingGuard } from './banking.guard';

describe('BankingGuard', () => {
  let guard: BankingGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(BankingGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
